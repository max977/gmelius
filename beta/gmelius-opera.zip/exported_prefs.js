opera.isReady(function(){
if (!widget.preferences.getItem("_OPERA_INTERNAL_defaultPrefsSet")){
widget.preferences.setItem("attleft", "off");
widget.preferences.setItem("ads", "on");
widget.preferences.setItem("footer", "off");
widget.preferences.setItem("btnnav", "on");
widget.preferences.setItem("fonts", "on");
widget.preferences.setItem("enlarge", "off");
widget.preferences.setItem("defrow", "on");
widget.preferences.setItem("labelsr", "off");
widget.preferences.setItem("colrow", "FAFAFA");
widget.preferences.setItem("statusc", "on");
widget.preferences.setItem("coloriz", "off");
widget.preferences.setItem("atticons", "on");
widget.preferences.setItem("chat", "off");
widget.preferences.setItem("consider", "off");
}
widget.preferences.setItem("_OPERA_INTERNAL_defaultPrefsSet", true);

});
