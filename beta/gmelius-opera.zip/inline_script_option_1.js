opera.isReady(function(){
addEventListener('DOMContentLoaded', function() {
  var storage = widget.preferences;
  var glue = '\n';
  var formElements = document.querySelectorAll('input,select');
  var skip = hash('hidden,submit,image,reset,button');
  var multipleValues = hash('checkbox,select-multiple');
  var checkable = hash('checkbox,radio');
  function hash(str, glue) {
    var obj = {
    };
    var tmp = str.split(glue || ',');
    while (tmp.length) obj[tmp.pop()] = true;
    return obj;
  }
  function walkElements(callback) {
    var obj = [];
    for (var i = 0, element = null; element = formElements[i++]; ) {
      var type = element.type.toLowerCase();
      var name = element.name || '';
      if (skip[type] === true || name == '') continue;
      var tmp = callback(element, name, type);
      if (tmp != null) obj.push(tmp);
    }
    return obj;
  }
  function changedElement(e) {
    var element = e.currentTarget || e;
    var type = element.type.toLowerCase();
    var name = element.name || '';
    var value = multipleValues[type] !== true ? element.value : walkElements(function(e, n, t) {
      if (n == name && e.options) {
        var tmp = [];
        for (var j = 0, option = null; option = e.options[j++]; ) {
          if (option.selected) {
            tmp.push(option.value);
          }
        }
        return tmp.join(glue);
      } else if (n == name && checkable[t] === true && e.checked) {
        return e.value;
      }
    }).join(glue);
    storage.setItem(name, value);
  }
  function setText(id, txt) {
    var e = document.getElementById(id);
    if (e) {
      e.textContent = txt;
    }
  }
  setText('widget-title', widget.name);
  setText('widget-name', widget.name);
  setText('widget-author', widget.author);
  setText('widget-version', widget.version);
  setText('widget-version2', widget.version);
  walkElements(function(element, name, type) {
    var value = storage[name] !== undefined ? storage.getItem(name) : element.value;
    var valueHash = hash(value, glue);
    if (element.selectedOptions) {
      for (var j = 0, option = null; option = element.options[j++]; ) {
        option.selected = valueHash[option.value] === true;
      }
    } else if (checkable[type] === true) {
      element.checked = valueHash[element.value] === true;
    } else {
      element.value = value;
    }
    if (storage[name] == undefined) {
      changedElement(element);
    }
    element.addEventListener('change', changedElement, true);
  });
}, false);
});
